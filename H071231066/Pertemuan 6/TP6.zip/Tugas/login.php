<?php 
include "./data.php";

session_start();

if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$loginSukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($users as $user) {
        if (($user['username'] === $username || $user['email'] === $username) && password_verify($password, $user['password'])) {
            $loginSukses = true;
            $_SESSION['username'] = $user['username'];
            break;
        }
    }

    if ($loginSukses) {
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['error'] = "Login gagal! Username/email atau password salah.";
        header("Location: login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white rounded-lg shadow-xl flex max-w-xl">
        <!-- Bagian Kiri: Gambar -->
        <div class="w-1/2">
            <img src="image/1.jpg" alt="Login Image" class="w-full h-full object-cover rounded-l-lg">
        </div>
        <!-- Bagian Kanan: Form -->
        <div class="w-1/2 p-8 flex items-center justify-center">
            <div class="w-full">
                <h2 class="text-xl font-bold mb-6 text-center">Log In</h2>
                <form action="#" method="POST">
                    <div class="mb-4">
                        <label for="username" class="block text-gray-700 font-medium text-sm">Username or Email</label>
                        <input type="text" id="username" name="username" class="mt-1 w-full px-4 py-2 border-b border-gray-300 rounded-none focus:border-blue-500 focus:outline-none" required>
                    </div>
                    <div class="mb-6">
                        <label for="password" class="block text-gray-700 font-medium text-sm">Password</label>
                        <input type="password" id="password" name="password" class="mt-1 w-full px-4 py-2 border-b border-gray-300 rounded-none focus:border-blue-500 focus:outline-none" required>
                    </div>
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600">Log In</button>
                </form>
            </div>
        </div>
    </div>

    <?php
    if (isset($_SESSION['error'])) {
        echo "<script>alert('" . $_SESSION['error'] . "');</script>";
        unset($_SESSION['error']);
    }
    ?>
</body>
</html>
