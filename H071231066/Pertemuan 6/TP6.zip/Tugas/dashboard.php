<?php
include "./data.php";
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$currentUsername = $_SESSION['username'];
$currentUserData = null;

$isAdmin = false;

foreach ($users as $user) {
    if ($user['username'] === $currentUsername) {
        $currentUserData = $user;
        if ($user['name'] === 'Admin') {
            $isAdmin = true;
        }
        break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-4">Dashboard</h1>
        
        <?php if ($isAdmin): ?>
            <h2 class="text-xl font-semibold">Data Seluruh Pengguna</h2>
            <table class="min-w-full bg-white shadow-md rounded-lg">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b">Email</th>
                        <th class="py-2 px-4 border-b">Username</th>
                        <th class="py-2 px-4 border-b">Nama</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td class="py-2 px-4 border-b"><?= htmlspecialchars($user['email']); ?></td>
                            <td class="py-2 px-4 border-b"><?= htmlspecialchars($user['username']); ?></td>
                            <td class="py-2 px-4 border-b"><?= htmlspecialchars($user['name']); ?></td>
                        </tr>
                        <h1>TEST</h1>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <h2 class="text-xl font-semibold">Data Anda</h2>
            <table class="min-w-full bg-white shadow-md rounded-lg">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b">Email</th>
                        <th class="py-2 px-4 border-b">Username</th>
                        <th class="py-2 px-4 border-b">Nama</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="py-2 px-4 border-b"><?= htmlspecialchars($currentUserData['email']); ?></td>
                        <td class="py-2 px-4 border-b"><?= htmlspecialchars($currentUserData['username']); ?></td>
                        <td class="py-2 px-4 border-b"><?= htmlspecialchars($currentUserData['name']); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
        <a href="logout.php" class="mt-4 inline-block bg-red-500 text-white py-2 px-4 rounded">Logout</a>
    </div>
</body>
</html>
