const simbol_kartus = {
    1: 'Hati Hitam',
    2: 'Hati Merah',
    3: 'Wajik Hitam',
    4: 'Wajik Merah',
    5: 'Sekop Hitam',
    6: 'Sekop Merah',
    7: 'Kelor Hitam',
    8: 'Kelor Merah'
};

const nomor_kartus = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];

let dek_kartu = [];
let player_hand = [];
let bandar_hand = [];
let saldo = 5000;
let bet = 0;

let bagianKartuBandar = document.getElementById("bandar-cards");
let bagianKartuPlayer = document.getElementById("player-cards");
let saldoDisplay = document.getElementById("saldo-display");
let betDisplay = document.getElementById("bet-display");

let hitBtnElement = document.getElementById("hit-btn");
let stayBtnElement = document.getElementById("stay-btn");

let isDealerHidden = true;

function startGame() {
    let dek = [];
    for (let nomor of nomor_kartus) {
        for (let suitNumber = 1; suitNumber <= 8; suitNumber++) {
            let gambarKartu = `${nomor}.${suitNumber}.png`;

            dek.push({
                nomor_kartu: nomor,
                simbol_kartu: simbol_kartus[suitNumber],
                image: gambarKartu
            });
        }
    }
    shuffleDeck(dek);
    return dek;
}

function shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
}

function updateSaldo() {
    saldoDisplay.textContent = saldo;
}

function updateBet() {
    betDisplay.textContent = bet;
}

function enableButtons() {
    hitBtnElement.disabled = false;
    stayBtnElement.disabled = false;
}

function disableButtons() {
    hitBtnElement.disabled = true;
    stayBtnElement.disabled = true;
}

function drawCard() {
    if (dek_kartu.length === 0) {
        dek_kartu = startGame(); 
    }
    return dek_kartu.pop();
}

function renderCard(hand, bagianKartu, hide = false, index = 0) {
    bagianKartu.innerHTML = '';
    hand.forEach((card, idx) => {
        let cardImg = document.createElement("img");
        if (hide && idx === 1 && isDealerHidden) {
            cardImg.src = `deck-of-cards/Back.png`; 
            cardImg.alt = `Card Back`;
        } else {
            cardImg.src = `deck-of-cards/${card.image}`;
            cardImg.alt = `${card.nomor_kartu} ${card.simbol_kartu}`;
        }
        cardImg.style.width = "60px";
        cardImg.style.marginRight = "5px";
        bagianKartu.appendChild(cardImg);
    });
}

function hitBtn() {
    if (player_hand.length === 0) {
        // Start new game
        player_hand = [drawCard(), drawCard()];
        bandar_hand = [drawCard(), drawCard()];
        renderCard(player_hand, bagianKartuPlayer);
        renderCard(bandar_hand, bagianKartuBandar, true);
    } else {
        player_hand.push(drawCard());
        renderCard(player_hand, bagianKartuPlayer);
        checkPlayerScore();
    }
}

function checkPlayerScore() {
    let playerScore = calculateScore(player_hand);
    if (playerScore > 21) {
        alert("You Bust! Bandar Wins!");
        resetGame();
    }
}

function stay() {
    isDealerHidden = false;
    renderCard(bandar_hand, bagianKartuBandar, false);
    
    while (calculateScore(bandar_hand) < 17) {
        bandar_hand.push(drawCard());
        renderCard(bandar_hand, bagianKartuBandar, false);
    }
    determineWinner();
}

function determineWinner() {
    let playerScore = calculateScore(player_hand);
    let bandarScore = calculateScore(bandar_hand);


    if (bandarScore > 21 || playerScore > bandarScore) {
        alert("You Win!");
        saldo += bet * 2;
        updateSaldo();
    } else if (playerScore < bandarScore) {
        alert("Bandar Wins!");
    } else {
        alert("It's a Tie!");
        saldo += bet;
    }

    resetGame();
}

function calculateScore(hand) {
    let score = 0;
    let aceCount = 0;

    hand.forEach(card => {
        if (card.nomor_kartu === 'A') {
            aceCount++;
            score += 11;
        } else if (['J', 'Q', 'K'].includes(card.nomor_kartu)) {
            score += 10;
        } else {
            score += parseInt(card.nomor_kartu);
        }
    });

    while (score > 21 && aceCount > 0) {
        score -= 10;
        aceCount--;
    }

    return score;
}

function resetGame() {
    bet = 0;
    updateBet();
    player_hand = [];
    bandar_hand = [];
    bagianKartuPlayer.innerHTML = '';
    bagianKartuBandar.innerHTML = '';
    dek_kartu = startGame(); 
    disableButtons(); 
    isDealerHidden = true; 
}


function bet5(){
    if (saldo >= 5) { 
        saldo -= 5;
        bet += 5;
        updateSaldo();
        updateBet();
        enableButtons(); 
    } else {
        alert("Saldo tidak cukup!");
    }
}

function bet25(){
    if (saldo >= 25) {
        saldo -= 25;
        bet += 25;
        updateSaldo();
        updateBet();
        enableButtons();
    } else {
        alert("Saldo tidak cukup!");
    }
}

function bet50() {
    if (saldo >= 50) {
        saldo -= 50;
        bet += 50;
        updateSaldo();
        updateBet();
        enableButtons();
    } else {
        alert("Saldo tidak cukup!");
    }
}

function bet100() {
    if (saldo >= 100) {
        saldo -= 100;
        bet += 100;
        updateSaldo();
        updateBet();
        enableButtons(); 
    } else {
        alert("Saldo tidak cukup!");
    }
}

function mainPage() {
    window.location.href = 'mainPage.html';
}

// Inisialisasi permainan
dek_kartu = startGame();
updateSaldo();
updateBet();
disableButtons();